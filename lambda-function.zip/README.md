# Get page token to post facebook page

see facebook_token/README.md

# How to create zip to upload

```
$ pip install -r requests.txt -t ./
$ zip -r ./lambda-function.zip .
```
