### Start CGIServer

```
$ easy_install pip
$ pip install -r requirements.txt -t ./
$ python -m CGIHTTPServer
```

### Access CGI

Access the next URL with your browser.

`http://localhost:8000/cgi-bin/index`
