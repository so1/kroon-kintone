#!/usr/bin/env python
# -*- encoding: utf-8 -*-

from datetime import datetime
import sys
import json
import facebook
import requests

API_TOKEN = 'HPZ6edZXgGXcxwef6IbdXgmSsoyYMQmSNGx65Uq3'
PAGE_TOKEN = 'EAACEdEose0cBAMyLnZATkttZBKRf21ZCwaWpyMpjYO7C2sZCSw1jmGrX71EYtnEFCW7pukPRZBRphA478Oc44LPnfuFZA3DQzo7iZApxI1Foa9LZCZBfo7G5eUbnRMGW35Mzu9RwQD8Xudcj6aLQWr4VERM9dyMlDVv9WNkVcI2osCZAdWbzRTTHi2yn2VbYThmBcZD'

class Timeline:
    def __init__(self):
        self.page_endpoint = facebook.GraphAPI(PAGE_TOKEN)

    def post_page(self, message):
        self.page_endpoint.put_wall_post(message=message)

def lambda_handler(event, context):
    resp = requests.get('https://bozuman.cybozu.com/k/guest/2862/v1/records.json?app=22498', headers={'X-Cybozu-API-Token': API_TOKEN});
    records = json.loads(resp.text)['records']

    line = u'{名前}({ニックネーム}) \n{説明}\n'
    message = '{}\n\n'.format(datetime.now())

    for record in records:
        data = dict( (k, v['value']) for k, v in record.items())
        message += line.format(**data)

    try:
        timeline = Timeline()
        timeline.post_page(message)
    except (IOError, facebook.GraphAPIError) as e:
        print e
        exit(9)
lambda_handler({}, {})
